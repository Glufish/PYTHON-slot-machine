# Slot Machine python flow diagram



